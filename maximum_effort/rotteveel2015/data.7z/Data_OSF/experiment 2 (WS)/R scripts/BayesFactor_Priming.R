rm(list=ls())
setwd("C:/Users/Desktop/Analysis/")
source("sd_ttest.r")  #Ruud's t-test code

load("ResultsP.RData")



###TEST FOR GOOD WORDS END



###TEST FOR GOOD WORDS END
#results.cong=log(ResultsP$RT_end[ResultsP$good.bad == 'good' & ResultsP$Condition == 'cong'])
#results.incong=log(ResultsP$RT_end[ResultsP$good.bad == 'good' & ResultsP$Condition == 'incong'])

###TEST FOR GOOD WORDS START
#results.cong=log(ResultsP$RT_start[ResultsP$good.bad == 'good' & ResultsP$Condition == 'cong'])
#results.incong=log(ResultsP$RT_start[ResultsP$good.bad == 'good' & ResultsP$Condition == 'incong'])

###TEST FOR BAD WORDS END
results.cong=log(ResultsP$RT_end[ResultsP$good.bad == 'bad' & ResultsP$Condition == 'cong'])
results.incong=log(ResultsP$RT_end[ResultsP$good.bad == 'bad' & ResultsP$Condition == 'incong'])

###TEST FOR BAD WORDS START
#results.cong=log(ResultsP$RT_start[ResultsP$good.bad == 'bad' & ResultsP$Condition == 'cong'])
#results.incong=log(ResultsP$RT_start[ResultsP$good.bad == 'bad' & ResultsP$Condition == 'incong'])

###TEST FOR cONG VS INCONG WORDS END
#results.cong=log(ResultsP$RT_end[ResultsP$Condition == 'cong'])
#results.incong=log(ResultsP$RT_end[ResultsP$Condition == 'incong'])

##COMPARING GOOD VS BAD WORDS
#results.cong=log(ResultsP$RT_end[ResultsP$good.bad == 'good'])
#results.incong=log(ResultsP$RT_end[ResultsP$good.bad == 'bad'])

#measurement FOR MOOVEMENT GOOD WORDS 
#results.cong=log((ResultsP$RT_end[ResultsP$good.bad == 'good' & ResultsP$Condition == 'cong'])-(ResultsP$RT_start[ResultsP$good.bad == 'good' & ResultsP$Condition == 'cong']))
#results.incong=log((ResultsP$RT_end[ResultsP$good.bad == 'good' & ResultsP$Condition == 'incong'])-(ResultsP$RT_start[ResultsP$good.bad == 'good' & ResultsP$Condition == 'incong']))

#measurement FOR MOOVEMENT BAD WORDS
#results.cong=log((ResultsP$RT_end[ResultsP$good.bad == 'bad' & ResultsP$Condition == 'cong'])-(ResultsP$RT_start[ResultsP$good.bad == 'bad' & ResultsP$Condition == 'cong']))
#results.incong=log((ResultsP$RT_end[ResultsP$good.bad == 'bad' & ResultsP$Condition == 'incong'])-(ResultsP$RT_start[ResultsP$good.bad == 'bad' & ResultsP$Condition == 'incong']))


mean(results.cong)
mean(results.incong)

Total=SD(group1=results.cong,
         group2=results.incong,
         iters=10000,
         burns=5001,
         chains=5,
         thins=1,
         sample=1,
         sig=1,
         wod=getwd(),
         prior='cauchy',
         dcheck=2,			#extra check
         plot=T,
         bugsdir = "c:/Program Files/winBUGS14"
)

apply(Total$BF,2,mean)

####################################
rm(list=ls())
setwd("C:/Users/Desktop/Analysis/")
source("sd_ttest.r")	#Ruud's t-test code
load("ResultsP.RData")
#load("Sequential_Analyse_Priming.RData")
BF_priming = rep(NA,150)

nsets = 50 #total (biggest amoung of pp in one condition)
###TEST FOR GOOD WORDS END
#results.cong=log(ResultsP$RT_end[ResultsP$good.bad == 'good' & ResultsP$Condition == 'cong'])
#results.incong=log(ResultsP$RT_end[ResultsP$good.bad == 'good' & ResultsP$Condition == 'incong'])

###TEST FOR GOOD WORDS START
#results.cong=log(ResultsP$RT_start[ResultsP$good.bad == 'good' & ResultsP$Condition == 'cong'])
#results.incong=log(ResultsP$RT_start[ResultsP$good.bad == 'good' & ResultsP$Condition == 'incong'])

###TEST FOR BAD WORDS END
#results.cong=log(ResultsP$RT_end[ResultsP$good.bad == 'bad' & ResultsP$Condition == 'cong'])
#results.incong=log(ResultsP$RT_end[ResultsP$good.bad == 'bad' & ResultsP$Condition == 'incong'])

###TEST FOR BAD WORDS START
results.cong=log(ResultsP$RT_start[ResultsP$good.bad == 'bad' & ResultsP$Condition == 'cong'])
results.incong=log(ResultsP$RT_start[ResultsP$good.bad == 'bad' & ResultsP$Condition == 'incong'])

###TEST FOR cONG VS INCONG WORDS END
#results.cong=log(ResultsP$RT_end[ResultsP$Condition == 'cong'])
#results.incong=log(ResultsP$RT_end[ResultsP$Condition == 'incong'])

#measurement FOR MOOVEMENT GOOD WORDS 
#results.cong=log((ResultsP$RT_end[ResultsP$good.bad == 'good' & ResultsP$Condition == 'cong'])-(ResultsP$RT_start[ResultsP$good.bad == 'good' & ResultsP$Condition == 'cong']))
#results.incong=log((ResultsP$RT_end[ResultsP$good.bad == 'good' & ResultsP$Condition == 'incong'])-(ResultsP$RT_start[ResultsP$good.bad == 'good' & ResultsP$Condition == 'incong']))

#measurement FOR MOOVEMENT BAD WORDS
#results.cong=log((ResultsP$RT_end[ResultsP$good.bad == 'bad' & ResultsP$Condition == 'cong'])-(ResultsP$RT_start[ResultsP$good.bad == 'bad' & ResultsP$Condition == 'cong']))
#results.incong=log((ResultsP$RT_end[ResultsP$good.bad == 'bad' & ResultsP$Condition == 'incong'])-(ResultsP$RT_start[ResultsP$good.bad == 'bad' & ResultsP$Condition == 'incong']))


#which(is.na(congruent))==which(is.na(incong))
#Related = Related[!is.na(Related)]
# Unrelated = Unrelated[!is.na(Unrelated)]
nsets = length(results.cong)

for(i in 2:nsets){
  
  Total=SD(group1=results.cong[1:i],group2=results.incong[1:i],iters=10000,burns=5001,
           chains=5,thins=1,sample=1,sig=1,wod=getwd(),prior='cauchy',
           dcheck=1,plot=F,bugsdir = "c:/Program Files/winBUGS14")
  
  BF_priming[i] = mean(Total$BF[,2])
}

save(BF_priming,file="Sequential_Analysis_Priming.RData")

###############################################################################################################################
####################################
rm(list=ls())
setwd("C:/Users/Desktop/Analysis/")
source("sd_ttest.r")	#Ruud's t-test code
load("ResultsP.RData")
load("Sequential_Analysis_Priming.RData")
nsets = 50

BF_priming

minmax = 10

postscript("SequentialBF_Priming.eps",paper = "special" ,width=14, height=8,horizontal=F)
par(las=1,mar=c(5,10,3,10),cex.main=1.6,cex.lab=1.6)
plot(1:nsets,log(BF_priming[1:nsets]),axes=F,ylim=c(-log(minmax ),log(minmax )),xlab="Number of participants/conditon",ylab="",type="l",
     lwd=3,main="Log Bayes factor for negative stimuli words (initiation time)")
axis(1,at=1:nsets)
axis(2,at=c(-log(minmax ),-log(10),-log(3),0,log(3),log(10), log(minmax )),
     label = c(paste(paste("-log(",minmax,sep=""),")",sep=""),"-log(10)","-log(3)","0","log(3)","log(10)",paste(paste("log(",minmax,sep=""),")",sep="")))
mtext(expression(paste(plain(logBF)[0][1])),side=2,line=3.75,cex=1.5)
lines(c(0,nsets ),c(0,0),lty=2,lwd=3)
lines(c(1,nsets ),c(log(10),log(10)),lty=2,lwd=2,col="gray")
lines(c(1,nsets ),c(-log(10),-log(10)),lty=2,lwd=2,col="gray")
arrows(nsets,log(10),nsets,log(minmax),lwd=2)
arrows(nsets,-log(10),nsets,-log(minmax),lwd=2)
mtext("Strong evidence \n in favor of H0",side=4,at=log(10),cex=1.2)
mtext("Strong evidence \n in favor of H1",side=4,at=-log(10),cex=1.2)
dev.off()


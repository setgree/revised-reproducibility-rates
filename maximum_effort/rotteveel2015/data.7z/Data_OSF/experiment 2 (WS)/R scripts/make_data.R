rm(list=ls())
setwd("C:/Users/Desktop/Analysis/")
source("fill_function.R")


for (i in 1:54){
  MakePrimingData(i)
}


load("ResultsP.RData")


warnings()

ResultsP

#### Remove cases (wrong experimental procedure) ### 

ResultsP=ResultsP[ResultsP$ParticipantNumber!='6',]
ResultsP=ResultsP[ResultsP$ParticipantNumber!='9',]
ResultsP=ResultsP[ResultsP$ParticipantNumber!='12',]
ResultsP=ResultsP[ResultsP$ParticipantNumber!='39',]

save(ResultsP,file="ResultsP.RData")

write.csv(ResultsP, file = 'ResultsP.csv')

save(ResultsP,file="ResultsP.csv")

 

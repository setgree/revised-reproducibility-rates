MakePrimingData = function(Ppn){
  
  setwd("C:/Users/Desktop/Analysis/")
  load("ResultsP.RData")
  
  setwd("C:/Users/Desktop/Analysis/")
  
  data_all = read.table(paste(Ppn,"_lever_test 2.txt", sep = ""), header= F, sep="\t", skip = 14, col.names = c("words", "valence", "condition", "rt_start", "rt_end","val"))
  
  
  ### mean RT ###
  
  
  RT_end_bad_cong  = data_all[data_all$rt_end & data_all$valence == '2' & data_all$condition =='1',]
  RT_end_bad_cong  = RT_end_bad_cong[RT_end_bad_cong$rt_end >= 300, ]
  RT_end_bad_cong  = RT_end_bad_cong[RT_end_bad_cong$rt_end <= 1500, ]
  
  RT_end_good_cong =  data_all[data_all$rt_end & data_all$valence == '1' & data_all$condition =='1',]
  RT_end_good_cong = RT_end_good_cong[RT_end_good_cong$rt_end >= 300, ]
  RT_end_good_cong = RT_end_good_cong[RT_end_good_cong$rt_end <= 1500, ]  
  
  RT_end_bad_incong = data_all[data_all$rt_end & data_all$valence == '2' & data_all$condition =='2',]
  RT_end_bad_incong = RT_end_bad_incong[RT_end_bad_incong$rt_end >= 300, ]
  RT_end_bad_incong = RT_end_bad_incong[RT_end_bad_incong$rt_end <= 1500, ]
  
  RT_end_good_incong = data_all[data_all$rt_end & data_all$valence == '1' & data_all$condition =='2',]
  RT_end_good_incong = RT_end_good_incong[RT_end_good_incong$rt_end >= 300, ]
  RT_end_good_incong = RT_end_good_incong[RT_end_good_incong$rt_end <= 1500, ]
  
  
  RT_start_bad_cong   = RT_end_bad_cong[RT_end_bad_cong$rt_start & RT_end_bad_cong$valence == '2',]
  
  RT_start_good_cong =  RT_end_good_cong[RT_end_good_cong$rt_start & RT_end_good_cong$valence == '1',]
  
  RT_start_bad_incong = RT_end_bad_incong[RT_end_bad_incong$rt_end & RT_end_bad_incong$valence == '2',]
  
  RT_start_good_incong = RT_end_good_incong[RT_end_good_incong$rt_start & RT_end_good_incong$valence == '1',]
  
  
  
  
  
  
  ResultsP[ResultsP$ParticipantNumber == Ppn & ResultsP$good.bad == 'good'& ResultsP$Condition == "cong",]$RT_start = mean(RT_start_good_cong$rt_start)
  ResultsP[ResultsP$ParticipantNumber == Ppn & ResultsP$good.bad == 'bad' & ResultsP$Condition == "cong",]$RT_start = mean(RT_start_bad_cong$rt_start)
  ResultsP[ResultsP$ParticipantNumber == Ppn & ResultsP$good.bad == 'good'& ResultsP$Condition == "cong",]$RT_end = mean(RT_end_good_cong$rt_end)
  ResultsP[ResultsP$ParticipantNumber == Ppn & ResultsP$good.bad == 'bad' & ResultsP$Condition == "cong",]$RT_end = mean(RT_end_bad_cong$rt_end)
  
  ResultsP[ResultsP$ParticipantNumber == Ppn & ResultsP$good.bad == 'good'& ResultsP$Condition == "incong",]$RT_start = mean(RT_start_good_incong$rt_start)
  ResultsP[ResultsP$ParticipantNumber == Ppn & ResultsP$good.bad == 'bad' & ResultsP$Condition == "incong",]$RT_start = mean(RT_start_bad_incong$rt_start)
  ResultsP[ResultsP$ParticipantNumber == Ppn & ResultsP$good.bad == 'good'& ResultsP$Condition == "incong",]$RT_end =  mean(RT_end_good_incong$rt_end)
  ResultsP[ResultsP$ParticipantNumber == Ppn & ResultsP$good.bad == 'bad' & ResultsP$Condition == "incong",]$RT_end =  mean(RT_end_bad_incong$rt_end)
  
  
  
 
  
  
  setwd("C:/Users/Desktop/Analysis/")
  save(ResultsP,file="ResultsP.RData")
  
}
#   }#  

load("ResultsP.RData")
ResultsP
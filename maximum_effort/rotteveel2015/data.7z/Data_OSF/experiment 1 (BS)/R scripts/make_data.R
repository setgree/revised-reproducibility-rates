rm(list=ls())
setwd("C:/Users/Desktop/Analysis/")
source("fill_function.R")


for (i in 1:100){
MakePrimingData(i)
}


load("ResultsP.RData")


warnings()

ResultsP

ResultsP=ResultsP[ResultsP$ParticipantNumber!='62',]
save(ResultsP,file="ResultsP.RData")

write.csv(ResultsP, file='Results.experiment1.csv')




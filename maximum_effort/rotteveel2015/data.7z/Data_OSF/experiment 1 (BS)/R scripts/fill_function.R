MakePrimingData = function(Ppn){
  
  setwd("C:/Users/Desktop/Analysis/")
  load("ResultsP.RData")
  
  setwd("C:/Users/Desktop/Analysis/")
  
  data_all = read.table(paste(Ppn,"_lever_test.txt", sep = ""), header= F, sep="\t", skip = 14, col.names = c("words", "1", "push.pull", "rt_start", "rt_end","val"))
  data_all = data_all[data_all$words!="Stereo",]
  
  
### mean RT ###
    
#### removes outlier smaller than 300 and longer than 3000 ###

RT_end_bad = data_all[data_all$rt_end & data_all$val == 'b',]
RT_end_bad=  RT_end_bad[RT_end_bad$rt_end >= 300, ]
RT_end_bad = RT_end_bad[RT_end_bad$rt_end <= 3000, ]

RT_end_good = data_all[data_all$rt_end & data_all$val == 'g',]
RT_end_good = RT_end_good[RT_end_good$rt_end >= 300, ]
RT_end_good = RT_end_good[RT_end_good$rt_end <= 3000, ]                         



RT_start_bad = RT_end_bad$rt_start
RT_start_bad = RT_start_bad[RT_start_bad > 0]

#RT_start_good = RT_end_good[RT_end_good$rt_start,]


#RT_start_good = data_all[data_all$rt_start & data_all$val == 'g',]
RT_start_good = RT_end_good$rt_start
RT_start_good = RT_start_good[RT_start_good > 0]

###Is mean RT < 1200 ms?###
# Mean = mean(data$ParticipantNumbe$RT)


# RT_corr_rel = data$RT[data$Trial_Type==1 & data$Response==2 & data$Accuracy==1]






ResultsP[ResultsP$ParticipantNumber == Ppn & ResultsP$good.bad == 'good',]$RT_start = mean(RT_start_good)
ResultsP[ResultsP$ParticipantNumber == Ppn & ResultsP$good.bad == 'bad',]$RT_start = mean(RT_start_bad)
ResultsP[ResultsP$ParticipantNumber == Ppn & ResultsP$good.bad == 'good',]$RT_end = mean(RT_end_good$rt_end, na.rm=TRUE)
ResultsP[ResultsP$ParticipantNumber == Ppn & ResultsP$good.bad == 'bad',]$RT_end = mean(RT_end_bad$rt_end, na.rm=TRUE)


setwd("C:/Users/alex/Desktop/Internship/Analysis/")
save(ResultsP,file="ResultsP.RData")

     }
#   }#  

load("ResultsP.RData")
ResultsP

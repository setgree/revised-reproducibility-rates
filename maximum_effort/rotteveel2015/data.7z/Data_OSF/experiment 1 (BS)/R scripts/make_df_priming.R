rm(list=ls())
setwd("C:/Users/Desktop/Analysis/")

ResultsP = data.frame(ParticipantNumber = rep(c(1:100),each=2), good.bad = rep(c('good','bad')), Condition = rep(c("cong","incong"),each=2), RT_start = rep(NA), RT_end = rep(NA))
# Condition = rep(c("cong","incong")

save(ResultsP, file="ResultsP.RData")
 

ResultsP


